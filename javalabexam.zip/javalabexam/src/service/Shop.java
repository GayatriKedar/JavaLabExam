package service;

import java.util.ArrayList;

import entity.Customer;
import entity.Product;
import entity.Transaction;
import exception.CustomerNotFoundException;
import exception.ProductNotFoundException;

public class Shop {

	private ArrayList<Product> products = new ArrayList<>();
	private ArrayList<Customer> customers = new ArrayList<>();
	private ArrayList<Transaction> transactions = new ArrayList<Transaction>();

	public void addProduct(Product product) {
		products.add(product);
		System.out.println("Product added successfully.");
	}

	public void addCustomer(Customer customer) {
		customers.add(customer);
		System.out.println("Customer added successfully.");
	}

	public void listProducts() {
		if (products.isEmpty()) {
			System.out.println("No products available.");
		} else {
			System.out.println("\nAvailable Products:");
			for (Product product : products) {
				System.out.println(product);
			}
		}
	}

	public void listCustomers() {
		if (customers.isEmpty()) {
			System.out.println("No customers available.");
		} else {
			System.out.println("\nAvailable Cusatomers:");
			for (Customer customer : customers) {
				System.out.println(customer);
			}
		}
	}

	public void deleteProduct(int productId) throws ProductNotFoundException {
		boolean found = false;
		for (Product product : products) {
			if (product.getPid() == productId) {
				products.remove(product);
				found = true;
				System.out.println("Product removed successfully.");
				break;
			}
		}
		if (!found) {
			throw new ProductNotFoundException("Product not found!");
			// System.out.println("Product not found.");
		}

	}

	public void sellProduct(int productId, int quantity) {
		for (Product product : products) {
			if (product.getPid() == productId) {
				if (product.getQuantity() >= quantity) {
					product.setQuantity(product.getQuantity() - quantity);
					System.out.println("Sold " + quantity + " units of " + product.getpName() + ".");
					System.out.println("Total price: $" + (product.getPrice() * quantity));
				} else {
					System.out.println("Insufficient stock!");
				}
				return;
			}
		}
		System.out.println("Product not found.");
	}

	public void deleteCustomer(int customerId) throws CustomerNotFoundException {
		boolean found = false;
		for (Customer customer : customers) {
			if (customer.getCid() == customerId) {
				customers.remove(customer);
				found = true;
				System.out.println("Customer removed successfully.");
				break;
			}
		}
		if (!found) {
			throw new CustomerNotFoundException("Customer not found!");
			// System.out.println("Customer not found.");
		}

	}

	public void processTransaction(int customerId, int productId, int quantity) {
		Customer customer = null;
		Product product = null;

		for (Customer c : customers) {
			if (c.getCid() == customerId) {
				customer = c;
				break;
			}
		}

		for (Product p : products) {
			if (p.getPid() == productId) {
				product = p;
				break;
			}
		}

		if (customer == null) {
			System.out.println("Customer not found.");
			return;
		}
		if (product == null) {
			System.out.println("Product not found.");
			return;
		}

		if (quantity > product.getQuantity()) {
			System.out.println("Insufficient stock for " + product.getpName() + ".");
			return;
		}

		product.setQuantity(product.getQuantity() - quantity);
		Transaction transaction = new Transaction(customer, product, quantity);
		transactions.add(transaction);
		System.out.println("Transaction successful: " + quantity + " of " + product.getpName() + " sold to "
				+ customer.getcName() + " " + "for $" + transaction.getTotalPrice());
	}
}
