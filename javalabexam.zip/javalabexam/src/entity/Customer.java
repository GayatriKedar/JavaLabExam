package entity;

public class Customer {
	private static int id = 0;
	private int cid;
	private String cName;
	private int no;

	public Customer(String cName, int no) {
		super();
		this.cid = ++id;
		this.cName = cName;
		this.no = no;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

}
