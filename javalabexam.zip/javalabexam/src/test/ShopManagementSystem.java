package test;

import java.util.Scanner;

import entity.Product;
import exception.CustomerNotFoundException;
import exception.ProductNotFoundException;
import entity.Customer;
import service.Shop;

public class ShopManagementSystem {
	public static void main(String[] args) throws Exception {
		Scanner scanner = new Scanner(System.in);
		Shop shop = new Shop();

		while (true) {
			System.out.println("\nShop Management System");
			System.out.println("1. Add Product");
			System.out.println("2. List Products");
			System.out.println("3. Delete Product");
			System.out.println("4. Sell Product");
			System.out.println("5. Add Customer");
			System.out.println("6. List Customer");
			System.out.println("7. Delete Customer");
			System.out.println("8. Transaction");
			System.out.println("9. Exit");
			System.out.print("Enter your choice: ");
			int choice = scanner.nextInt();

			switch (choice) {
			case 1:

//				System.out.print("Enter Product ID: ");
//				int id = scanner.nextInt();
				scanner.nextLine();

				System.out.print("Enter Product Name: ");
				String name = scanner.nextLine();
				System.out.print("Enter Product Price: ");
				double price = scanner.nextDouble();
				System.out.print("Enter Product Quantity: ");
				int quantity = scanner.nextInt();
				Product product = new Product(name, price, quantity);
				shop.addProduct(product);
				break;

			case 2:

				shop.listProducts();
				break;

			case 3:

				System.out.print("Enter Product ID to delete: ");
				int productIdToDelete = scanner.nextInt();
				shop.deleteProduct(productIdToDelete);
				break;

			case 4:

				System.out.print("Enter Product ID to sell: ");
				int productIdToSell = scanner.nextInt();
				System.out.print("Enter quantity to sell: ");
				int quantityToSell = scanner.nextInt();
				shop.sellProduct(productIdToSell, quantityToSell);
				break;

			case 5:
				System.out.print("Enter Customer Name: ");
				name = scanner.next();
				System.out.print("Enter Customer No: ");
				int no = scanner.nextInt();
				Customer customer = new Customer(name, no);
				shop.addCustomer(customer);
				break;

			case 6:
				shop.listCustomers();
				break;

			case 7:
				System.out.print("Enter Customer ID to delete: ");
				int customerId = scanner.nextInt();
				shop.deleteCustomer(customerId);
				break;

			case 8:

				System.out.print("Enter customer ID: ");
				int customerId1 = scanner.nextInt();
				System.out.print("Enter product ID: ");
				int productId = scanner.nextInt();
				System.out.print("Enter quantity: ");
				int quantity1 = scanner.nextInt();
				shop.processTransaction(customerId1, productId, quantity1);
				break;

			case 9:

				System.out.println("Thank you for visit...");
				scanner.close();
				return;

			default:
				System.out.println("Invalid choice, please try again.");
			}
		}
	}
}
